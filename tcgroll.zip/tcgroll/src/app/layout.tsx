// src/app/layout.tsx
import type { Metadata } from 'next'
import './globals.css'
import { Providers } from '@/components/providers'
import { Navbar } from '@/components/layout/navbar'
import { Toaster } from 'react-hot-toast'

export const metadata: Metadata = {
  title: 'TCGRoll — Pokémon Card Case Opening',
  description: 'Open virtual Pokémon card cases, collect rare cards, and build your ultimate collection.',
  keywords: ['pokemon', 'tcg', 'card opening', 'case opening', 'collectibles'],
  openGraph: {
    title: 'TCGRoll — Pokémon Card Case Opening',
    description: 'Open virtual Pokémon card cases and collect rare cards.',
    type: 'website',
  },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="noise">
      <body className="mesh-bg min-h-screen">
        <Providers>
          <Navbar />
          <main className="min-h-screen">{children}</main>
          <Toaster
            position="bottom-right"
            toastOptions={{
              style: {
                background: '#151d38',
                color: '#e2e8f0',
                border: '1px solid rgba(251,191,36,0.2)',
                fontFamily: 'var(--font-body)',
              },
              success: { iconTheme: { primary: '#fbbf24', secondary: '#000' } },
              error: { iconTheme: { primary: '#ef4444', secondary: '#fff' } },
            }}
          />
        </Providers>
      </body>
    </html>
  )
}
